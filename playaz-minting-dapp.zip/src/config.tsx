const TWITTER_URL = 'https://www.twitter.com/';
const DISCORD_URL = 'https://www.discord.gg/';
const WAITING = 30000;
const REACT_TOKEN_NAME="Playaz";
const REACT_NFT_AUTORITY = "5FVEye7HEo7Sq5fQLDuBP4NQKp4uKXUcw8WxERy8nAiF";
const PROGRAM_ID = 'metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s';
const DEV_NET = 'https://api.devnet.solana.com';
export {
    TWITTER_URL,
    DISCORD_URL,
    WAITING,
    REACT_TOKEN_NAME,
    REACT_NFT_AUTORITY,
    PROGRAM_ID,
    DEV_NET
}